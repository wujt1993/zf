let adminURL = [
    '/sys/borrow/approval',
    '/sys/book/queryByPage',
    '/sys/book/insert',
    '/sys/book/update',
    '/sys/book/delete',
    '/sys/bookCategory/insert',
    '/sys/bookCategory/update',
    '/sys/bookCategory/delete',
]

module.exports = adminURL;