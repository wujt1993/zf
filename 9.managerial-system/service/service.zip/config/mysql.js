//mysql.js
// MySQL数据库联接配置封裝
var mysql = {
    host: '127.0.0.1',
    user: 'root',
    password: 'root',
    database: 'managerial-system',
    port: 3306
};
module.exports = mysql;