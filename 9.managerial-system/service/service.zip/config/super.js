let superURL = [
    '/sys/user/queryByPage',
    '/sys/user/setRole',
]

module.exports = superURL;