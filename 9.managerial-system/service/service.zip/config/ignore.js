
let ignoreURL = [
    '/sys/user/register',
    '/sys/user/login',
    '/sys/user/logout'
]

module.exports = ignoreURL;