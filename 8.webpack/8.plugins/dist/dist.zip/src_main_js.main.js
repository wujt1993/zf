(self["webpackChunk_8_plugins"] = self["webpackChunk_8_plugins"] || []).push([["src_main_js"],{

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const title = __webpack_require__(/*! ./title */ "./src/title.js");
module.exports = `main ~ ${title}`;

/***/ }),

/***/ "./src/title.js":
/*!**********************!*\
  !*** ./src/title.js ***!
  \**********************/
/***/ ((module) => {

module.exports =  "title";

/***/ })

}]);